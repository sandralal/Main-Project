
<?php?>
<!DOCTYPE html>
<html>
<head>

<link rel="stylesheet"
href="style-home.css">

</head>
<body>
   
 
    <div class="container">
        

    
        <header>

        <div class="head"> 
                <div class="imgclass">
                    <img src="logo.jpg" style="float: left">
                    <span class="heading" style="float: left;">PaweSome</span>
                </div>
            <div >
                <ul>
                
                    <li ><a href="login.php" >Login</a></li>
                    <li><a href="#contact">Services</a></li>
                    <li><a href="#about">About</a></li>
                    <li  ><a  href="home.php">Home</a></li>
                
                </ul>
        </div>
  </div>
</header>
<div class="background_img">
    <img class="img-div" src="./homepage.jpg">
    <h3 class="textMessages">Helpers improve their world</h3>
    <div class="donate-button">
        <a href="login.php"><b>DONATE</b></a>
        
    </div>
    
    
</div>

 <div  class="des"> 
    <h4 >PaweSome<br><br>
        Join our initiative to speak for the voiceless...
        <br>PaweSome aims at rescuing the needed animals<br>
        not just words but a promise..<br>
        put our hands together for rewriting their future.. 
        
           
      
    
         </h4>
         
    
    
</div>




  <div class="services">
    <div class="items">
        <div class="item first">
            <div class="content">
                <h1>Be a volunteer,<br>join our team</h1>
                <p>Join our team PaweSome and become our volunteer & help animals<br><br>
                Right time...right choice</p>
                <a href="sign_up.php"><b>REGISTER NOW</b></a>
            </div>
        </div>
        <div class="item second">
            <div class="content">
                <h1>Adopt your new companion</h1>
                <p>Adopt your new companion ,give wings to a new life <br>
                <br>
            Never late to start a change....</p>
                <a href="sign_up.php"><b>ADOPT NOW</b></a>
            </div>
        </div>
        <div class="item third">
            <div class="content">
                <h1>A pet sitter for every occasion</h1>
                <p>Local pet care services for your best friend.
                    <br>keeps your pets always  safe with us...</p>
                <a href="sign_up.php"><b>BOOK NOW</b></a>
            </div>
        </div>
    </div>

  </div>

</body>

</html>