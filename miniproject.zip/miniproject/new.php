<?php
session_start();
echo"{$_SESSION['useremail']}";

?>